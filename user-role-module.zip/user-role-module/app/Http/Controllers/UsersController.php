<?php

namespace App\Http\Controllers;
use App\Model\User;
use App\Model\Role;

use Illuminate\Http\Request;
use Validator,Response,DB,File;

class UsersController extends Controller
{
    
	/**
	* Function for display all Users 
	*
	* @param null
	*
	* @return view page. 
	*/
    public function list(){  
        $userList           =   User::query()
                                ->leftJoin("roles","users.role_id","roles.id")
                                ->select("users.*","roles.role_name")
                                ->get();
        $roleList           =   Role::query()
                                ->pluck("role_name","id");
        return view('User.index',compact('userList','roleList'));
    }

    
	/**
	* Function to save user data 
	*
	* @param null
	*
	* @return response. 
	*/
    public function saveUser(Request $request){
        $formData						=	$request->all();
		if(!empty($formData)){
			$validator 					=	Validator::make(
				$request->all(),
				array(
                    'name'                    => 'required',
                    'email'                   => 'required|email|unique:users',
                    'phone_number'            => 'required|numeric|digits_between:0,10',
                    'description'             => 'required',
                    'role_id'                 => 'required',
                    'profile_image'           => 'required|mimes:jpeg,jpg,png'
				)
			);
            if ($validator->fails()){
				$response		    =	array(
					'success' 		=> 	0,
					'errors' 		=> 	$validator->errors()
				);
				return Response::json($response); 
				die;
			}else{
                DB::begintransaction();
				$obj 							=  	new User;
				$obj->name					    =  	$request->name;
				$obj->email 					=  	$request->email;
				$obj->phone_number				=  	$request->phone_number;
				$obj->description 				=  	$request->description;
				$obj->role_id 					=  	$request->role_id;
                
				if($request->hasFile('profile_image')){
					$extension 	=	 $request->file('profile_image')->getClientOriginalExtension();
					$fileName	=	time().'-image.'.$extension;
					
					$folderName     	= 	strtoupper(date('M'). date('Y'))."/";
					$folderPath			=	$folderName;
					if(!File::exists($folderPath)) {
						File::makeDirectory($folderPath, $mode = 0777,true);
					}
					if($request->file('profile_image')->move(public_path('/profile_image/'.$folderName), $fileName)){
						$obj->profile_image	=	$folderName.$fileName;
					}
				}
                $obj->save();

				if(!empty($obj->id)){
                    DB::commit();
                    $getUser        =   User::query()
                                        ->where("users.id",$obj->id)
                                        ->leftJoin("roles","users.role_id","roles.id")
                                        ->select("users.*","roles.role_name")
                                        ->first();
    				$returnHTML 		= 	View("User.user_row", compact('getUser'))->render(); 

                    $response		    =	array(
                        'success' 		=> 	1,
                        'errors' 		=> 	'',
                        'message' 		=> 	"User added successfully",
                        "returnHtml"    =>  $returnHTML
                    );
                    return Response::json($response); 
                    die;
                }else{
                    DB::rollback();
                    $response		    =	array(
                        'success' 		=> 	0,
                        'errors' 		=> 	'',
                        'message' 		=> 	"Something went wrong. Please try again"
                    );
                    return Response::json($response); 
                    die;
                }
			

			
            }
        }else{
            $response		    =	array(
                'success' 		=> 	0,
                'errors' 		=> 	'',
                'message'       =>  'Invalid Request'
            );
            return Response::json($response); 
            die;
        }
        $this->validate($request, $rules, $errorMessage);

        $imageName = time().'.'.$request->profile_image->getClientOriginalExtension();
        $request->profile_image->move(public_path('/'), $imageName);
      
        User::create([
         'name'             => $request->name,
         'email'            => strtolower($request->email),
         'phone_number'     => $request->phoen_number,
         'description'      => $request->description,
         'role_id'          => $request->role_id,
         'profile_image'    => $imageName
          ]);

        $this->meesage('message','User created successfully!');
        return redirect()->back();

    }
    //
}

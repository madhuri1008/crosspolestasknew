<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    //
    protected $fillable = [
        'name',
        'email',
        'phone_number',
        'description',
        'role_id',
        'profile_image',
    ];
   
}

<?php if(!empty($getUser)): ?>
    <tr>
        <td><?php echo e(ucwords($getUser->name)); ?></td>
        <td><?php echo e($getUser->email); ?></td>
        <td><?php echo e($getUser->phone_number); ?></td>
        <td><?php echo e($getUser->role_name); ?></td>
        <td><img src="<?php echo e(url('public/profile_image/'.$getUser->profile_image)); ?>" height="70" width="70"></td>
        <td><?php echo e($getUser->description); ?></td>
    </tr>
<?php endif; ?><?php /**PATH G:\xampp\htdocs\crossPoles\resources\views/User/user_row.blade.php ENDPATH**/ ?>
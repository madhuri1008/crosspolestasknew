<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Task</title>
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

        <!-- Styles -->
        <style>
            .is-invalid{
                color:red
            }
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-12" style="padding:20px">
                        <div class="col-md-12">
                            All Users
                            <a style="float:right" href="javascript:void(0)" class="btn btn-primary addUserBtn">Add New User</a>
                        </div>
                    </div>
                    <div class="col-md-12 showUserForm" style="padding-bottom:20px;display:none">
                        <div class="row">
                            <form class="" name="userForm" id="userForm">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Name</label>
                                    <input type="text" class="form-control valid" name="name" id="name" placeholder="Enter name">
                                    <small class=""></small>
                                </div>
                                <br/>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email</label>
                                    <input type="text" class="form-control valid validEmail" name="email" id="email" placeholder="Enter email">
                                    <small class=""></small>
                                </div>
                                <br/>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Phone Number</label>
                                    <input type="email" class="form-control valid validPhone" name="phone_number" id="phone_number" placeholder="Enter Phone Number">
                                    <small class=""></small>
                                </div>
                                <br/>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Select Role</label>
                                    <select name="role_id" id="role_id" class="form-control valid">
                                        <option value="">Select Role</option>
                                        @if(!empty($roleList))
                                            @foreach($roleList as $roleKey => $roleValue)
                                                <option value="{{$roleKey}}">
                                                    {{$roleValue}}
                                                </option>
                                            @endforeach
                                        @endif
                                    </select>
                                    <small class=""></small>
                                </div>
                                <br/>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Description</label>
                                    <textarea name="description" id="description" row="3" col="5" class="form-control valid">
                                        </textarea>
                                        <small class=""></small>
                                </div>
                                <br/>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Profile Picture</label>
                                    <input type="file" name="profile_image" id="profile_image" class="valid">
                                    <small class=""></small>
                                </div>
                                <button type="button" class= " submitBtn btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-12" style="padding-bottom:20px">
                        <table class="table" id="userTable">
                            <thead>
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Phone Number</th>
                                    <th scope="col">Role</th>
                                    <th scope="col">Profile Picture</th>
                                    <th scope="col">Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(!$userList->isEmpty())
                                    @foreach($userList as $userLis)
                                        <tr>
                                            <td>{{ucwords($userLis->name)}}</td>
                                            <td>{{$userLis->email}}</td>
                                            <td>{{$userLis->phone_number}}</td>
                                            <td>{{$userLis->role_name}}</td>
                                            <td><img src="{{url('public/profile_image/'.$userLis->profile_image)}}" height="70" width="70"></td>
                                            <td>{{$userLis->description}}</td>
                                        </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td colspan="6">
                                            <div style="text-align:center">No Record found</div>
                                        </td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $(document).on("click",".addUserBtn",function(){
                $("#userForm")[0].reset();
                $(".showUserForm").toggle();
            });

            $(document).on("click",".submitBtn",function(){
                $(".is-invalid").removeClass("is-invalid");
                var errorCount = 0;
                $('.valid').each(function(){
                    var id		    =	$(this).attr('id');
                    var value	   =	$(this).val();
                    
                    if(value.length == 0 || value=='' || value==undefined ){
                        $('#'+id).next().addClass('is-invalid');
                        $('#'+id).next().html("This field is required");
                        $('#'+id).next().show();
                        errorCount++;
                    }else{
                        if($("#"+id).hasClass('validPhone')){  
                            const regexPhoneNumber = /^[0]?(91)?[789]\d{9}$/; 
                            if (!value.match(regexPhoneNumber)) {
                                $('#'+id).next().addClass('is-invalid');
                                $('#'+id).next().html("Phone number must be valid");
                                $('#'+id).next().show();
                                errorCount++;
                            }        
                        }else if($("#"+id).hasClass('validEmail')){
                            const pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i
                            if (!value.match(pattern)) {
                                $('#'+id).next().addClass('is-invalid');
                                $('#'+id).next().html("Email must be valid");
                                $('#'+id).next().show();
                                errorCount++;
                            } 
                        }
                    } 
                });
                if(errorCount == 0){
                    var form    	=   $('#userForm')[0];
                    $.ajax({
                        headers     :   {"X-CSRF-TOKEN":"{{ csrf_token() }}"},
                        url			: 	"{{route('user.saveUser')}}",
                        method		: 	'POST',
                        data		: 	new FormData(form),
                        beforeSend	: 	function() {
                            $(".submitBtn").prop('disabled',true);
                        },
                        cache		: 	false,
                        contentType	: 	false,
                        processData	: 	false,
                        success     :   function(r){
                            error_array 	= 	JSON.stringify(r);
                            datas			=	JSON.parse(error_array);
                            $(".submitBtn").prop('disabled',false);
                            if(datas['success'] == 1) {
                                $("#userForm")[0].reset();
                                $(".showUserForm").toggle();
                                $('#userTable tr:last').after(datas['returnHtml']);
                            }else {
                                if(datas['errors'] != ''){
                                    $.each(datas['errors'],function(index,html){
                                        $("input[name = "+index+"]").next().addClass('is-invalid');
                                        $("input[name = "+index+"]").next().html(html);
                                        $("input[name = "+index+"]").next().show();
                                        $("select[name = "+index+"]").next().addClass('is-invalid');
                                        $("select[name = "+index+"]").next().html(html);
                                        $("select[name = "+index+"]").next().show();
                                        $("textarea[name = "+index+"]").next().addClass('is-invalid');
                                        $("textarea[name = "+index+"]").next().html(html);
                                        $("textarea[name = "+index+"]").next().show();
                                    });
                                }else{
                                    alert(datas['message']);
                                }
                            }
                        }
                    });
                }
            }) 
                
        </script>
    </body>
</html>

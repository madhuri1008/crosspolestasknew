@if(!empty($getUser))
    <tr>
        <td>{{ucwords($getUser->name)}}</td>
        <td>{{$getUser->email}}</td>
        <td>{{$getUser->phone_number}}</td>
        <td>{{$getUser->role_name}}</td>
        <td><img src="{{url('public/profile_image/'.$getUser->profile_image)}}" height="70" width="70"></td>
        <td>{{$getUser->description}}</td>
    </tr>
@endif